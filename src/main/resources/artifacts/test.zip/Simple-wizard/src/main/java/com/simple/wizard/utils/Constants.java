package com.simple.wizard.utils;

public final class Constants {
	public static final int PROGRESS_MAX_VALUE = 100;
}
