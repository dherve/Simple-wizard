package com.simple.wizard.utils;


public class PropertyKeys {
	public static final String FOLDER_SELECTED = "folderSelected";
	public static final String TASK_COMPLETE = "installationComplete";
	public static final String LAUNCH_APPLICATION = "launchApplication";
}
